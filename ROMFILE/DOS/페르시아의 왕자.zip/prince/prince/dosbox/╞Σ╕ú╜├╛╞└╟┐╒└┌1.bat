cd "dosbox"
start "/r" dosbox_kor.exe -noconsole -conf "dosbox.conf" 